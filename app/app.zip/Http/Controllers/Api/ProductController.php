<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Product;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Http\Resources\ProductResource;
use Illuminate\Support\Facades\Validator;

class ProductController extends Controller
{
    public function index(Request $request)
    {
        // Get the search query from the request
        $searchQuery = $request->search;
    
        // Query products with the category relationship and apply search filter if provided
        $products = Product::with('category')
            ->when($searchQuery, function ($query) use ($searchQuery) {
                $query->where('name', 'like', '%' . $searchQuery . '%');
            })
            ->latest()
            ->get();
    
        // Return the filtered products with an API resource
        return new ProductResource(true, 'List Data Products', $products);
    }
    
    public function withPagination()
    {
        $products = Product::with('category')->when(request()->search, function ($products) {
            $products = $products->where('name', 'like', '%' . request()->search . '%');
        })->latest()->paginate(5);

        //append query string to pagination links
        $products->appends(['search' => request()->search]);

        //return with Api Resource
        return new ProductResource(true, 'List Data Products', $products);
    }

    public function show($id)
    {
        $product = Product::with('category')->whereId($id)->first();

        if ($product) {
            //return success with Api Resource
            return new ProductResource(true, 'Detail Data Product!', $product);
        }

        //return failed with Api Resource
        return new ProductResource(false, 'Detail Data Product Tidak DItemukan!', null);
    }


  
}