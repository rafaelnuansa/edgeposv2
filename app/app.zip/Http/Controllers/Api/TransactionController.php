<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Transaction;
use App\Models\TransactionDetail;
use App\Http\Resources\TransactionResource;
use Illuminate\Http\Request;
use Illuminate\Support\Str; // Import Str class

class TransactionController extends Controller
{
    public function index(Request $request)
    {
        // Get all transactions from latest with pagination
        $transactions = Transaction::with('details.product')->latest()->paginate(10);

        // Use the TransactionResource to format the response
        return new TransactionResource(true, 'Transactions retrieved successfully', $transactions);
    }

    // create transaction
    public function store(Request $request)
    {

        try {
            // Validate the request data for the transaction
            $validatedData = $request->validate([
                'customer_id' => 'nullable|exists:customers,id',
                'cash' => 'required',
                'change' => 'required',
                'discount' => 'required',
                'total_amount' => 'required',
                'payment_method' => 'required',
                'remaining_amount' => 'required|numeric',
                'status' => 'required|string',
            ]);


            // Generate a unique invoice ID
            $invoice = 'INV-' . Str::random(8); // You can customize the format

            // Add the generated invoice ID to the validated data
            $validatedData['invoice'] = $invoice;

            // Create a new transaction instance
            $transaction = new Transaction($validatedData);
            $transaction->cashier_id = auth()->guard('api')->user()->id;
            $transaction->cash = $request->cash;
            $transaction->change = $request->change;
            $transaction->payment_method = $request->payment_method;
            $transaction->discount = $request->discount;

            $transaction->total_amount = $request->total_amount;
            $transaction->remaining_amount = $request->remaining_amount;
            $transaction->status = $request->status;
            $transaction->customer_id = $request->customer_id ?? null;
            // Save the transaction to the database
            $transaction->save();

            // Now, let's add transaction details if provided in the request
            if ($request->has('transaction_details')) {
                $transactionDetails = $request->input('transaction_details');

                // Loop through the details and create records
                foreach ($transactionDetails as $detail) {
                    $transactionDetail = new TransactionDetail([
                        'transaction_id' => $transaction->id,
                        'product_id' => $detail['product_id'],
                        'qty' => $detail['qty'],
                        'price' => $detail['price'],
                    ]);

                    // Save the transaction detail to the database
                    $transactionDetail->save();
                }
            }

            // Use the TransactionResource to format the response
            return new TransactionResource(true, 'Transaction created successfully', $transaction);
        } catch (\Exception $e) {
            // Handle the exception here
            return new TransactionResource(false, $e->getMessage(), null);
        }
    }


}
