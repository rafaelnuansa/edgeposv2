<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Customer;
use App\Models\Product;
use App\Models\Transaction;
use App\Models\TransactionDetail;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SalesController extends Controller
{
    public function index(Request $request)
    {
        // Dapatkan semua input filter dari formulir
        $filter = $request->only(['start_date', 'end_date', 'start_time', 'end_time', 'customer', 'cashier', 'time']);

        $transactions = Transaction::query();

        if (!empty($filter['start_date'])) {
            $transactions->whereDate('created_at', '>=', $filter['start_date']);
        }

        if (!empty($filter['end_date'])) {
            $transactions->whereDate('created_at', '<=', $filter['end_date']);
        }

        if (!empty($filter['start_time'])) {
            $transactions->whereTime('created_at', '>=', $filter['start_time']);
        }

        if (!empty($filter['end_time'])) {
            $transactions->whereTime('created_at', '<=', $filter['end_time']);
        }

        if (isset($filter['customer']) && $filter['customer'] !== 'all') {
            $transactions->where('customer_id', $filter['customer']);
        }

        if (isset($filter['cashier']) && $filter['cashier'] !== 'all') {
            $transactions->where('cashier_id', $filter['cashier']);
        }

        if (isset($filter['time'])) {
            // You can safely access the "time" key here
            if ($filter['time'] === 'custom') {
                // Handle the custom time logic here

                // Pastikan Anda memiliki elemen start_time dan end_time dalam filter
                if (isset($filter['start_time']) && isset($filter['end_time'])) {
                    // Anda dapat menggunakan nilai $filter['start_time'] dan $filter['end_time']
                    // untuk menerapkan filter waktu kustom ke dalam query
                    $start_time = $filter['start_time'];
                    $end_time = $filter['end_time'];

                    // Contoh: Menambahkan filter waktu kustom ke dalam query
                    $transactions->whereTime('created_at', '>=', $start_time);
                    $transactions->whereTime('created_at', '<=', $end_time);
                }
            }
        }

        $transactions = $transactions->get();

        // Mengambil data penjualan dari database
        // $transactions = Transaction::latest();

        $customers = Customer::all();
        $cashiers = User::all();

        // Mengirim data penjualan ke tampilan Sales Summary
        return view('sales.summary', compact('transactions', 'customers', 'cashiers'));
    }

    public function sales_by_product()
    {
        // Retrieve sales data grouped by products
        $salesByProduct = TransactionDetail::select('product_id', DB::raw('SUM(qty) as total_sold'))
            ->with('product') // Load the related product model
            ->groupBy('product_id')
            ->get();

        return view('sales.by_product', compact('salesByProduct'));
    }



    public function sales_by_category()
    {
        // Retrieve sales data grouped by categories
        $salesByCategory = TransactionDetail::select('categories.name as category_name', DB::raw('SUM(transaction_details.qty) as total_sold'))
            ->join('products', 'transaction_details.product_id', '=', 'products.id')
            ->join('categories', 'products.category_id', '=', 'categories.id')
            ->groupBy('category_name')
            ->get();

        return view('sales.by_category', compact('salesByCategory'));
    }



}
