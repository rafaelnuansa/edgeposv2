<?php

namespace App\Http\Controllers;

use App\Models\Transaction;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    /**
     * Handle the incoming request.
     */
    public function __invoke(Request $request)
    {
        $greeting = "Welcome"; // Customize the greeting as needed
        $currentTime = now(); // Get the current time
        $salesData = [
            'netSales' => Transaction::sum('total_amount'),
            'costOfSales' => 0, // Replace with the actual column name
            'grossProfit' => 0, // Replace with the actual column name
        ];
        // You can pass data to the view
        return view('dashboard.index', compact('greeting', 'currentTime', 'salesData'));
    }
}
