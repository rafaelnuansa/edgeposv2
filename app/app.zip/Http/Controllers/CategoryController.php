<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category; // Pastikan Anda telah mengimpor model Category
use Illuminate\Database\QueryException;

class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $categories = Category::all();
        return view('categories.index', compact('categories'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('categories.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        try {
            $request->validate([
                'name' => 'required|unique:categories',
            ]);

            Category::create([
                'name' => $request->input('name'),
            ]);

            return redirect()->route('categories.index')->with('success', 'Category created successfully.');
        } catch (QueryException $e) {
            // Jika ada pengecualian karena konflik unik (unique constraint), tangani di sini.
            return redirect()->back()->with('error', 'Category name must be unique.');
        } catch (\Exception $e) {
            // Tangani pengecualian umum di sini.
            return redirect()->back()->with('error', $e->getMessage());
        }
    }

    /**
     * Display the specified resource.
     */
    public function show($id)
    {
        $category = Category::findOrFail($id);
        return view('categories.show', compact('category'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        $category = Category::findOrFail($id);
        return view('categories.edit', compact('category'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        try {
            $request->validate([
                'name' => 'required|unique:categories,name,' . $id,
            ]);

            $category = Category::findOrFail($id);
            $category->update([
                'name' => $request->input('name'),
            ]);

            return redirect()->route('categories.index')->with('success', 'Category updated successfully.');
        } catch (QueryException $e) {
            // Jika ada pengecualian karena konflik unik (unique constraint), tangani di sini.
            return redirect()->back()->with('error', 'Category name must be unique.');
        } catch (\Exception $e) {
            // Tangani pengecualian umum di sini.
            return redirect()->back()->with('error', 'An error occurred while updating the category.');
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        $category = Category::findOrFail($id);
        $category->delete();
        return redirect()->route('categories.index')->with('success', 'Category deleted successfully.');
    }
}
